# ====== FILE MO PHONG - CHI DUNG CHO LAB, KHONG THUC HIEN HANH VI NAO ======
# Mo phong payload duoc kich hoat moi lan nguoi dung dang nhap.
Write-Host "Simulated payload: ransomware stage 2 launcher"

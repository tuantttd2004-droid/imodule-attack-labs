#!/bin/bash
# ===== MO PHONG TAN CONG RANSOMWARE - CHI CHAY TRONG LAB =====
# Chi tac dong len cac thu muc: victimdata, shadow_copies, registry
KEY=90
LOG=sysmon_sim.log
ts() { date '+%Y-%m-%d %H:%M:%S'; }

echo "[LAB] Bat dau mo phong tan cong..."

# Giai doan 1
find victimdata -type f > /dev/null
echo "$(ts) EventID=1  Image=cmd.exe  CommandLine=cmd /c dir /s victimdata" >> $LOG

# Giai doan 2
echo '"Updater"="powershell -ep bypass -File C:\Users\Victim\AppData\Local\Temp\update.ps1"' >> registry/HKCU_Run.reg
echo "$(ts) EventID=13 Image=reg.exe  TargetObject=HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\Updater" >> $LOG

# Giai doan 3
rm -f shadow_copies/*
echo "$(ts) EventID=1  Image=vssadmin.exe  CommandLine=vssadmin delete shadows /all /quiet" >> $LOG

# Giai doan 4
python3 xor_tool.py encrypt victimdata $KEY
for f in victimdata/*.locked; do
  echo "$(ts) EventID=11 Image=encrypt.exe  FileCreate=$f" >> $LOG
done
echo "Files da bi ma hoa. (Day la mo phong trong lab)" > victimdata/README_LOCKED.txt

echo "[LAB] Mo phong ket thuc. Hay dieu tra!"

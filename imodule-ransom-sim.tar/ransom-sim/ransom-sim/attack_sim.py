#!/usr/bin/env python3
# ===== MO PHONG TAN CONG RANSOMWARE - CHI CHAY TRONG LAB =====
# Chi tac dong len cac thu muc: victimdata, shadow_copies, registry
import glob
import os
import subprocess
import time

KEY = 90
LOG = "sysmon_sim.log"


def log(msg):
    with open(LOG, "a") as f:
        f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))


print("[LAB] Bat dau mo phong tan cong...")

# Giai doan 1
for _root, _dirs, _files in os.walk("victimdata"):
    pass
log(r"EventID=1  Image=cmd.exe  CommandLine=cmd /c dir /s victimdata")

# Giai doan 2
with open("registry/HKCU_Run.reg", "a") as f:
    f.write('"Updater"="powershell -ep bypass -File C:\\Users\\Victim\\AppData\\Local\\Temp\\update.ps1"\n')
log(r"EventID=13 Image=reg.exe  TargetObject=HKCU\Software\Microsoft\Windows\CurrentVersion\Run\Updater")

# Giai doan 3
for p in glob.glob("shadow_copies/*"):
    os.remove(p)
log(r"EventID=1  Image=vssadmin.exe  CommandLine=vssadmin delete shadows /all /quiet")

# Giai doan 4
subprocess.call(["python3", "xor_tool.py", "encrypt", "victimdata", str(KEY)])
for p in sorted(glob.glob("victimdata/*.locked")):
    log("EventID=11 Image=encrypt.exe  FileCreate=%s" % p)
with open("victimdata/README_LOCKED.txt", "w") as f:
    f.write("Files da bi ma hoa. (Day la mo phong trong lab)\n")

print("[LAB] Mo phong ket thuc. Hay dieu tra!")

#!/usr/bin/env python3
"""Cong cu XOR (dung de mo phong ma hoa/giai ma trong lab).
Cach dung:
    python3 xor_tool.py encrypt <thu_muc> <key 0-255>
    python3 xor_tool.py decrypt <thu_muc> <key 0-255>
"""
import os
import sys

MAGIC = b"CONFIDENTIAL:"


def xor(data, key):
    return bytes(b ^ key for b in data)


def main():
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(1)
    mode, folder = sys.argv[1], sys.argv[2]
    try:
        key = int(sys.argv[3])
    except ValueError:
        print("Key phai la so nguyen 0-255")
        sys.exit(1)
    if not (0 <= key <= 255) or not os.path.isdir(folder):
        print("Key hoac thu muc khong hop le")
        sys.exit(1)

    count = 0
    for name in sorted(os.listdir(folder)):
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            continue
        if mode == "encrypt" and not name.endswith(".locked"):
            with open(path, "rb") as f:
                data = f.read()
            with open(path + ".locked", "wb") as f:
                f.write(xor(data, key))
            os.remove(path)
            print("[ENCRYPT] %s -> %s.locked" % (name, name))
            count += 1
        elif mode == "decrypt" and name.endswith(".locked"):
            with open(path, "rb") as f:
                data = xor(f.read(), key)
            if not data.startswith(MAGIC):
                print("[SAI KEY] %s - khong giai ma duoc, bo qua" % name)
                continue
            with open(path[:-len(".locked")], "wb") as f:
                f.write(data)
            os.remove(path)
            print("[DECRYPT] %s -> %s" % (name, name[:-len(".locked")]))
            count += 1

    if mode == "decrypt" and count > 0:
        with open("recover.log", "w") as f:
            f.write("RECOVERED %d files using key %d\n" % (count, key))
        print("Da khoi phuc %d file. Xem recover.log" % count)
    elif count == 0:
        print("Khong co file nao duoc xu ly.")


if __name__ == "__main__":
    main()
